var fs = require('fs');
module.exports = function (req, res) {
    var def = false;
    function route(name, rend) {
        if (name == req.url) {
            res.writeHeader(200, {"Content-Type": "text/html"});

            fs.readFile('views/' + rend, function (err, html) {
                res.write(html);
                res.end();
            });
            def=true
        }else if(name=='deafult'&&!def){
            res.writeHeader(200, {"Content-Type": "text/html"});

            fs.readFile('views/' + rend, function (err, html) {
                res.write(html);
                res.end();
            });
        }
    }

    route('/', 'index.html');
    route('deafult', 'notFound.html');
}