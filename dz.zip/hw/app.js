var http = require('http');
http.createServer(function (req, res) {
    require('routs')(req,res);
}).listen(8080);