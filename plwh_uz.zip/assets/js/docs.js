$(".title").click(function () {
	$($(this.parentElement).find("iframe")[0]).slideToggle(400)
});
$(".doc iframe").each(function(){
	$(this).slideUp(0)
})